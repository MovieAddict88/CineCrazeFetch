package com.cineraze.stream.free.data.model.network

import com.cineraze.stream.free.data.model.entity.Genre
import com.google.gson.annotations.SerializedName

data class GenresResponse(
    @SerializedName("genres")
    override var results: List<Genre>
) : BaseListResponse<Genre>
