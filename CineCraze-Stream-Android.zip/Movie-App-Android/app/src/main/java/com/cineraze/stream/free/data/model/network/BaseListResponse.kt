package com.cineraze.stream.free.data.model.network

interface BaseListResponse<T> {
    var results: List<T>
}
