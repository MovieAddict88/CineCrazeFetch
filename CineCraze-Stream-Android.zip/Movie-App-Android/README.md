# CineCraze Stream 🎬

A modern Android movie streaming app built with Kotlin, featuring the latest movies, TV shows, and detailed information about cast and crew.

## 📱 Features

- **Browse Movies**: Discover popular, upcoming, and in-theater movies
- **TV Shows**: Explore trending and popular TV series
- **Detailed Information**: Get comprehensive details about movies, shows, cast, and crew
- **Beautiful UI**: Modern Material Design interface
- **Search Functionality**: Find your favorite movies and shows
- **High-Quality Images**: Stunning movie posters and backdrop images
- **Video Trailers**: Watch movie and TV show trailers

## 🛠️ Technical Stack

- **Language**: Kotlin
- **Architecture**: MVVM (Model-View-ViewModel)
- **UI**: View Binding, Data Binding
- **Navigation**: Android Navigation Components
- **Networking**: Retrofit2 + Gson
- **Image Loading**: Picasso
- **Async Operations**: Kotlin Coroutines
- **Lifecycle**: ViewModel, LiveData
- **API**: The Movie Database (TMDB)

## 📋 Requirements

- Android Studio Arctic Fox or later
- Minimum SDK: API 26 (Android 8.0)
- Target SDK: API 30 (Android 11)
- Gradle 7.0.2
- Java 11

## 🚀 Setup Instructions

1. **Clone the repository**
   ```bash
   git clone <your-repository-url>
   cd Movie-App-Android
   ```

2. **Get TMDB API Key**
   - Visit [The Movie Database (TMDB)](https://www.themoviedb.org/)
   - Create an account and get your API key
   - The API key is already configured in `local.properties`

3. **Configure Android SDK**
   - Update `local.properties` with your Android SDK path:
   ```properties
   sdk.dir=/path/to/your/android/sdk
   tmdb_api_key="your_api_key_here"
   ```

4. **Build and Run**
   ```bash
   ./gradlew assembleDebug
   ```

## 📦 Package Structure

```
com.cineraze.stream.free/
├── data/
│   ├── db/
│   │   ├── remote/          # API interfaces
│   │   └── repository/      # Data repositories
│   └── model/
│       ├── entity/          # Data models
│       └── network/         # Network response models
├── ui/
│   ├── adapter/             # RecyclerView adapters
│   ├── binding/             # Data binding utilities
│   ├── home/                # Home screen
│   ├── movies/              # Movies screen
│   ├── tv_shows/            # TV Shows screen
│   ├── movie_details/       # Movie details
│   ├── tv_show_details/     # TV show details
│   ├── person_details/      # Cast/crew details
│   └── show_all/            # Show all items
└── util/
    └── extension/           # Kotlin extensions
```

## 🔧 Configuration

### Gradle Configuration
- **Gradle Version**: 7.0.2
- **Android Gradle Plugin**: 7.0.2
- **Kotlin Version**: 1.5.31
- **Compile SDK**: 30
- **Min SDK**: 26
- **Target SDK**: 30

### Dependencies
- AndroidX libraries
- Material Design Components
- Navigation Components
- Retrofit2 for networking
- Picasso for image loading
- Kotlin Coroutines

## 📸 Screenshots

*Add your app screenshots here*

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- [The Movie Database (TMDB)](https://www.themoviedb.org/) for providing the movie data API
- Original project inspiration from various Android movie apps
- Material Design guidelines for UI/UX inspiration

## 📞 Contact

For any questions or suggestions, feel free to reach out!

---

**CineCraze Stream** - Your gateway to the world of movies and entertainment! 🍿
